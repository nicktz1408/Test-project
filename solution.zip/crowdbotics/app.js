var express = require("express");
var mySQL = require("mysql");
var bodyParser = require("body-parser");

var dbConnection = mySQL.createConnection(
{
	host: "db43.grserver.gr",
	user: "cr_admin",
	password: "mc27mH$2",
	database: "crowdbotics"
});

var app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.get('/', function (req, res)
{
	res.sendfile('./static/html/index.html');
});

app.get('/api/questions', function (req, res)
{
	var selectQuery = "SELECT question, ansA, ansB, ansC, ansD FROM questions";

	dbConnection.query(selectQuery, function (err, rows, fields)
	{
		res.status(200).json({ status: "success", success: rows });
	});

});

app.post('/submit', function (req, res)
{
	var userAnswers = req.body.ans,
		totalQuestions = 10;

	if(!userAnswers || userAnswers.length !== totalQuestions)
		res.json({ status: "error", error: "Unaccepted format!" });

	else
	{
		var selectQuery = "SELECT answer FROM questions";
		//res.json({ ans: userAnswers });

		dbConnection.query(selectQuery, function (err, rows, fields)
		{
			var totalPoints = 0;

			for(var i = 0; i < totalQuestions; i++)
				if(rows[i].answer === userAnswers[i])
					totalPoints++;

			res.status(200).json({ status: "success", total: totalPoints });
		});
	}
});


app.listen(80);