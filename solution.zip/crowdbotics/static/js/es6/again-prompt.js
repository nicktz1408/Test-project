var AgainPrompt = React.createClass({
  render: function ()
  {
    <div className="row-4">
      <button className="submit btn btn-success">SUBMIT</button>
    </div>
  }
});