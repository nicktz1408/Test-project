var Question = React.createClass({
  render: function ()
  {
    return (
      <div className="question">
        <input type="radio" name={this.props.index}>{this.props.ansA}</input>
        <input type="radio" name={this.props.index}>{this.props.ansB}</input>
        <input type="radio" name={this.props.index}>{this.props.ansC}</input>
        <input type="radio" name={this.props.index}>{this.props.ansD}</input>
      </div>
    );
  }
});