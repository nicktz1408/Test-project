var Main = React.createClass({
  getInitialState: function ()
  {
    return { currState: "START", result: '-1' };
  },
  
  showQuestions: function ()
  {
    this.setState({ currState: "QUIZ" });
  },
  
  showResults: function (result)
  {
    this.setState({ currState: "AGAIN", result: result });
  },
  
  render: function ()
  {
    var state = this.state.currState;
    
    if(state === "START")
    {
      return (
        <Intro showQuestions={this.showQuestions}/>
      );
    }
    
    else if(state === "QUIZ")
    {
      return (
        <Questions />
      );
    }
    
    else if(state == "AGAIN")
    {
       return (
         <AgainPrompt />
       );
    }
  }
});