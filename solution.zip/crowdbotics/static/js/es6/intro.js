var Intro = React.createClass({
  handleClick: function ()
  {
    this.props.showQuestions();
  },
  
  render: function ()
  {
    return (
      <div className="row-1">
        <h1>QUIZ</h1>
        <button className="start btn btn-success" onClick={this.handleClick}>START</button>
      </div>
    );
  }
});