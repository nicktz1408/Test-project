var Questions = React.createClass({
  getInitialState: function ()
  {
    return ({ questions: [] });
  },
  
  componentDidMount: function ()
  {
    /*var getUrl = "/api/questions";
    
    fetch(getUrl)
      .then(data => data.json())
      .then(function (res)
      {
        if(res.status === "success")
          this.setState({ questions: res.success });
      }.bind(this));
    
    */
    
    this.state.questions = [
      {
        question: "HEY!",
        ansA: "A",
        ansB: "B",
        ansC: "C",
        ansD: "D"
      }
    ];
    
    this.forceUpdate();
  },
  
  handleClick: function ()
  {
    var postUrl = "/submit";
    
    fetch(postUrl)
      .then(data => data.json())
      .then(function (res)
      {
        var points = res.total;
      
        this.props.showResults(points);
      }.bind(this));
  },
  
  render: function ()
  {
    var questions = this.state.questions.map((question, index) => <Question question={question.question} ansA={question.ansA} ansB={question.ansB} ansC={question.ansC} ansD={question.ansD} index={index} />);
                                             
                                             console.log(questions);
                                             
    return (
      <div className="row-2">
        {questions}
        <div className="btn-cont">
          <button className="submit btn btn-success" onClick=       {this.handleClick}>SUBMIT</button>
        </div>
      </div>
    )
  }
});