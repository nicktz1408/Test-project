var Questions = React.createClass({
  displayName: "Questions",

  getInitialState: function getInitialState() {
    return { questions: [] };
  },

  componentDidMount: function componentDidMount() {
    var getUrl = "/api/questions";
    
    fetch(getUrl)
      .then(data => data.json())
      .then(function (res)
      {
        if(res.status === "success")
          this.setState({ questions: res.success });
      }.bind(this));

    this.forceUpdate();
  },

  handleClick: function ()
  {
    var size = 10, ans = [];
    
    for(var i = 0; i < size; i++)
    {
      var curr = $("#" + i).val().split('.')[0];
      
      ans.push(curr);
    }
    
    
    console.log(ans);
	var postUrl = "/submit";
    
    fetch(postUrl, 
    {
      method: "POST",
      headers:
      {
        "Accept": "application/json",
        "Content-Type": "application/json"
      },
	 "body": JSON.stringify(
        {
          ans: ans
        })
    })
      .then(data => data.json())
      .then(function (res)
      {
        var points = res.total;
		console.log(points);
      
        this.props.showResults(points);

      }.bind(this));
  },

  render: function render() {
    var questions = this.state.questions.map(function (question, index) {
      return React.createElement(Question, { question: question.question, ansA: question.ansA, ansB: question.ansB, ansC: question.ansC, ansD: question.ansD, index: index });
    });

    console.log(questions);

    return React.createElement(
      "div",
      { className: "row-2" },
      questions,
      React.createElement(
        "div",
        { className: "btn-cont" },
        React.createElement(
          "button",
          { className: "submit btn btn-success", onClick: this.handleClick },
          "SUBMIT"
        )
      )
    );
  }
});