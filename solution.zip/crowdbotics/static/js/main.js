var Main = React.createClass({
  displayName: "Main",

  getInitialState: function getInitialState() {
    return { currState: "START", result: '-1' };
  },

  showQuestions: function showQuestions() {
    this.setState({ currState: "QUIZ" });
  },

  showResults: function showResults(result) {
    this.setState({ currState: "AGAIN", result: result });
  },

  render: function render() {
    var state = this.state.currState;

    if (state === "START") {
      return React.createElement(Intro, { showQuestions: this.showQuestions });
    } else if (state === "QUIZ") {
      return React.createElement(Questions, { showResults: this.showResults });
    } else if (state == "AGAIN") {
      return React.createElement(AgainPrompt, { results: this.state.result });
    }
  }
});

ReactDOM.render(React.createElement(Main, null), document.getElementById("app"));