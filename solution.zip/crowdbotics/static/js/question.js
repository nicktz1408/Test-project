var Question = React.createClass({
  displayName: "Question",

  render: function render() {
    console.log("GOT IT!" + this.props.ansA);

    return React.createElement(
      "div",
      { className: "question" },
      React.createElement(
        "h4",
        null,
        this.props.question
      ),
      React.createElement(
        "select",
        { id: this.props.index },
        React.createElement(
          "option",
          null,
          "A. " + this.props.ansA
        ),
        React.createElement(
          "option",
          null,
          "B. " + this.props.ansB
        ),
        React.createElement(
          "option",
          null,
          "C. " + this.props.ansC
        ),
        React.createElement(
          "option",
          null,
          "D. " + this.props.ansD
        )
      )
    );
  }
});