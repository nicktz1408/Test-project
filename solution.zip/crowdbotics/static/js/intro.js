var Intro = React.createClass({
  displayName: "Intro",

  handleClick: function handleClick() {
    this.props.showQuestions();
  },

  render: function render() {
    return React.createElement(
      "div",
      { className: "row-1" },
      React.createElement(
        "h1",
        null,
        "QUIZ"
      ),
      React.createElement(
        "button",
        { className: "start btn btn-success", onClick: this.handleClick },
        "START"
      )
    );
  }
});