var AgainPrompt = React.createClass({
  displayName: "AgainPrompt2",

  render: function render() {
    return (React.createElement(
      "div",
      { className: "row-4" },
      React.createElement(
        "button",
        { className: "submit btn btn-success" },
        React.createElement(
          "a",
          { href: "/" },
          "AGAIN"
        )
      )
    ));
  }
});